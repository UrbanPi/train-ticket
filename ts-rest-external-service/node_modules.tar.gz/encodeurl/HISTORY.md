1.0.1 / 2016-06-09
==================

  * Fix encoding unpaired surrogates at start/end of string

1.0.0 / 2016-06-08
==================

  * Initial release
